#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int num, i, resultado = 0;
	
	//Processamento
	
	printf ("Oi! Digite um n�mero e direi se o n�mero � primo: ");
	scanf ("%d", &num);
	
	for (i = 2; i <= num/2; i++){
		if (num % i == 0) {
    	resultado++;
    	break;
	}
}
	if (num <= 1){
		printf ("%d n�o � um n�mero primo.\n", num);
	}

	else if (resultado == 0){
   		printf("%d � um n�mero primo.\n", num);
	}
	
	else {
    	printf("%d n�o � um n�mero primo.\n", num);
	}	return 0;
}	
