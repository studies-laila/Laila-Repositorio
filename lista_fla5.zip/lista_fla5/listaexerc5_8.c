#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis.
	int dias, salario, contador;
	float divisao;
	
	salario = 11000;
	divisao = salario /22;
	contador = 1;
	
	printf ("Funcion�rio, informe a quantidade de dias que voc� trabalhou no m�s: ");
	scanf ("%d", &dias);

	
	while (contador <= dias){
		divisao = divisao + 500;
		
		contador = contador + 1;
	}
	
	printf ("O seu sal�rio �: R$ %2.2f.", divisao-500);
	
	return 0;
}
	
	
