#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int dia;
	
	//Processamento
	printf ("Oi! Digite um n�mero e eu diria o dia da semana indicado: ");
	scanf ("%d", &dia);
	
	while (dia != 0){
	switch (dia)
	{
		case 1:
			printf ("\nO dia � domingo.\n\n");
		break;
		
		case 2:
			printf ("\nO dia � segunda-feira.\n\n");
		break;
		
		case 3:
			printf ("\nO dia � ter�a-feira.\n\n");
		break;
		
		case 4:
			printf ("\nO dia � quarta-feira.\n\n");
		break;
		
		case 5:
			printf ("\nO dia � quinta-feira.\n\n");
		break;
		
		case 6:
			printf ("\nO dia � sexta-feira.\n\n");
		break;
		
		case 7:
			printf ("\nO dia � s�bado.\n\n");
		break;
		
		default:
			printf ("\nEsse n�o � um dia da semana.\n\n");
			printf ("\nTente novamente.\n\n");
		break;
	
	}
	scanf ("%d", &dia);
	}
		
	return 0;
		
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
