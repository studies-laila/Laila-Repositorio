#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int num, num2, contagem;
	double multi, soma;
	
	//Processamento
	multi = 1;
	num = 28;
	num2 = 30;
	
	
	for (contagem=2; contagem <=num; contagem = contagem + 2){
		printf ("%f\n", multi-1);
		printf ("%d\n", contagem);
		multi = multi *contagem;
	}
	
	printf ("A multiplica��o dos n�meros pares de 1 a 30 �: %f\n\n", multi);
	
	for (contagem=1; contagem <=num2; contagem = contagem + 2){
		printf ("%f\n", soma);
		printf ("%d\n", contagem);
		soma = soma + contagem;
		
	}
	printf ("A soma dos n�meros impares de 1 a 30 �: %f\n", soma);
	


	return 0;
	
}

