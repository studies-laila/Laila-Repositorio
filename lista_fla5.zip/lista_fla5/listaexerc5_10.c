#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int menu, num1, fatorial, contador;
	float num2, num3, num4, resultado2, resultado3, resultado4;
	double num5;
	
	//Processamento
	
	printf ("Ol�! Esse � o menu: ");
	printf ("\n1 - Calcular o fatorial.");
	printf ("\n2 - Calcular a raiz quadrada de 3 n�meros.");
	printf ("\n3 - Imprime a tabuada completa de 1 ao 10.");
	printf ("\n4 - Sair do programa.");
	
	printf ("\nQual op��o voc� escolhe?\n" );
	scanf ("%d", &menu);
	
	while (menu == 1){
		printf ("\nAgora, digite um n�mero: ");
		scanf ("%d", &num1);
		
		fatorial = 1;
		contador = 1;
		
		while (contador <= num1){
			fatorial = fatorial * contador;
			contador = contador + 1;
		}
	
		printf ("\nO fatorial de %d! � %d", num1, fatorial);
	
	}
	
	while (menu == 2){
		printf ("\nAgora, digite um n�mero: ");
		scanf ("%f", &num2);
		resultado2 = sqrt (num2);
		
		printf ("\nDigite outro n�mero: ");
		scanf ("%f", &num3);
		resultado3 = sqrt (num3);

		printf ("\nDigite mais um n�mero: ");
		scanf ("%f", &num4);
		resultado4 = sqrt (num4);
		
		printf ("\nA raiz quadrada de %f � %f. ", num2, resultado2);
		printf ("\nA raiz quadrada de %f � %f. ", num3, resultado3);
		printf ("\nE a raiz quadrada de %f � %f. ", num4, resultado4);
		
	}
	
	while (menu == 3){
		num5 = 1;
		printf ("\nA tabuada de somar �: ");
		printf ("\n1 + 1 = %f", num5 + 1);
		printf ("\n2 + 1 = %f", num5 + 2);
		printf ("\n3 + 1 = %f", num5 + 3);
		printf ("\n4 + 1 = %f", num5 + 4);
		printf ("\n5 + 1 = %f", num5 + 5);
		printf ("\n6 + 1 = %f", num5 + 6);
		printf ("\n7 + 1 = %f", num5 + 7);
		printf ("\n8 + 1 = %f", num5 + 8);
		printf ("\n9 + 1 = %f", num5 + 9);
		printf ("\n10 + 1 = %f", num5 + 10);
		
		printf ("\nA tabuada de subtrair �: ");
		printf ("\n1 - 1 = %f", num5 - 1);
		printf ("\n2 - 1 = %f", 2 - num5);
		printf ("\n3 - 1 = %f", 3 - num5);
		printf ("\n4 - 1 = %f", 4 - num5);
		printf ("\n5 - 1 = %f", 5 - num5);
		printf ("\n6 - 1 = %f", 6 - num5);
		printf ("\n7 - 1 = %f", 7 - num5);
		printf ("\n8 - 1 = %f", 8 - num5);
		printf ("\n9 - 1 = %f", 9 - num5);
		printf ("\n10 - 1 = %f", 10 - num5);
		
		printf ("\nA tabuada de multiplicar �: ");
		printf ("\n1 * 1 = %f", num5 * 1);
		printf ("\n2 * 1 = %f", 2 * num5);
		printf ("\n3 * 1 = %f", 3 * num5);
		printf ("\n4 * 1 = %f", 4 * num5);
		printf ("\n5 * 1 = %f", 5 * num5);
		printf ("\n6 * 1 = %f", 6 * num5);
		printf ("\n7 * 1 = %f", 7 * num5);
		printf ("\n8 * 1 = %f", 8 * num5);
		printf ("\n9 * 1 = %f", 9 * num5);
		printf ("\n10 * 1 = %f", 10 * num5);
		
		printf ("\nA tabuada de dividir �: ");
		printf ("\n1 / 1 = %f", num5 / 1);
		printf ("\n2 / 1 = %f", 2 / num5);
		printf ("\n3 / 1 = %f", 3 / num5);
		printf ("\n4 / 1 = %f", 4 / num5);
		printf ("\n5 / 1 = %f", 5 / num5);
		printf ("\n6 / 1 = %f", 6 / num5);
		printf ("\n7 / 1 = %f", 7 / num5);
		printf ("\n8 / 1 = %f", 8 / num5);
		printf ("\n9 / 1 = %f", 9 / num5);
		printf ("\n10 / 1 = %f", 10 / num5);
		break;
	}
	
		while (menu == 4){
			return 0;
		}
		
		while (menu <1 || menu > 4) {
			printf ("\nEsse n�mero n�o est� no menu.");
			break;
			
	}
		
		return 0;
		
	}
