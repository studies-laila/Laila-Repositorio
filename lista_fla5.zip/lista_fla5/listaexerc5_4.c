#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	
	int x;
	
	//Processamento
	x = 10;
	
	//Como o programa deve executar o while 20 vezes, ele soma 10 a 1 por vinte vezes (logo x = 30).
	
	while (x < 30){
		x++;
		printf ("\nx = %d", x);
		++x;
	}
	
	//O algoritmo soma x a 1 mais 20 vezes. 
	
	do {
		x++;
		printf ("\nx = %d", x);
		
	} while (x <50);
	


	return 0;

}
