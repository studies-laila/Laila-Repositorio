#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int c1 = 0, c2 = 0;
	
	//Processamento
	for (c1 = 1; c1 <= 10; c1++){
		for (c2 = 1; c2 <= 10; c2++){
			if (c1 < c2){
		//	printf ("%d:%d ", c1, c2);
	//	} else {
			break;
		}
			printf ("%d:%d ", c1, c2);
		
	}

	printf ("\n");
	}
}

