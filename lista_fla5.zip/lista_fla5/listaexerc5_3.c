#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int mes;
	
	printf ("Oi! Insira um n�mero e eu direi o m�s correspondente: ");
	scanf ("%d", &mes);
	
	while (mes !=0){
	switch (mes)
	{
		case 1:
			printf ("\nJaneiro.\n\n");
		break;
		
		case 2:
			printf ("\nFevereiro.\n\n");
		break;
		
		case 3:
			printf ("\nMar�o.\n\n");
		break;
		
		case 4:
			printf ("\nAbril.\n\n");
		break;
		
		case 5:
			printf ("\nMaio.\n\n");
		break;
		
		case 6:
			printf ("\nJunho.\n\n");
		break;
		
		case 7:
			printf ("\nJulho.\n\n");
		break;
		
		case 8:
			printf ("\nAgosto\n\n.");
		break;
		
		case 9:
			printf ("\nSetembro.\n\n");
		break;
		
		case 10:
			printf ("\nOutubro.\n\n");
		break;
		
		case 11:
			printf ("\nNovembro.\n\n");
		break;
		
		case 12:
			printf ("\nDezembro.\n\n");
		break;
		
		default:
			printf ("\nM�s inv�lido.");
		break;
	}
	scanf ("%d", &mes);
	}		
		
		return 0;
	}
