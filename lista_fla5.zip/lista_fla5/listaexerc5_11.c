#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int altura, bmenor, bmaior, area;
	
	//Processamento
	printf ("Oi! Esse programa calcula a �rea de um trap�zio. Primeiro, insira a altura desse trap�zio: ");
	scanf ("%d", &altura);
	
	printf ("Agora, insira a base menor do trap�zio: ");
	scanf ("%d", &bmenor);
	
	printf ("E agora, insira a base maior: ");
	scanf ("%d", &bmaior);
	
	area = (altura * (bmenor+bmaior))/2;
	
	printf ("A �rea do trap�zio � %d", area);
	
	return 0;
	
}
