#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int dia;
	
	//Processamento
	printf ("Oi! Digite um n�mero e eu diria o dia da semana indicado: ");
	scanf ("%d", &dia);
	
	if (dia==1){
		printf ("\nO dia � domingo.");
	}
	
	else if (dia==2){
		printf ("\nO dia � segunda-feira.");
	}
	
	else if (dia==3){
		printf ("\nO dia � ter�a-feira.");
	}
	
	else if (dia==4){
		printf ("\nO dia � quarta-feira.");
	}
	
	else if (dia==5){
		printf ("\nO dia � quinta-feira.");
	}
	
	else if (dia==6){
		printf ("\nO dia � sexta-feira.");
	}
	
	else if (dia==7){
		printf ("\nO dia � s�bado.");
	}
	
	else if (dia <1 || dia >7) {
		printf ("\nEsse n�o � um dia da semana.");
	}
	
	return 0;
	
}
