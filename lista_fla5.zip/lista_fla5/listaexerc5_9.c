#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
	setlocale (LC_ALL, "Portuguese");
	
	//Vari�veis
	int num, soma = 0, i;
	
	//Processamento
	
	
	
	do{
		printf ("\nDigite um n�mero maior que zero: ");
		scanf ("%d", &num);
		
		if (num == 0){
			return 0;
		} else {
		

		for (i = 1; i < num; i++){
			if (num % i == 0){
			soma +=i;
			}
		}
		
		if (soma == num){
			printf ("\n%d � um n�mero perfeito.\n", num);
		} 
		else {
			printf ("\n%d n�o � um n�mero perfeito.\n", num);
		}
		
		soma = 0;
	}
	} while (num != 0);
	

	return 0;
		
	}
	
	
	
	
	

